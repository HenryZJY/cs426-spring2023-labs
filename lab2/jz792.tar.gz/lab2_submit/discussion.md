## B1
My prediction is that after I run kubetl delete pod, a new pod will be automatically generated because I specified the number of replicas to be 1. 

## B4
Welcome! You have chosen user ID 201113 (Bechtelar1827/victoriadaugherty@barrows.info)

Their recommended videos are:
 1. Caribouam: back up by Kaleb Bernhard
 2. The motionless hound's understanding by Henri Lueilwitz
 3. funny Chicory by Reyna Fahey
 4. Deerbeen: quantify by Murl Parker
 5. angry on by Armand Baumbach

## C3
With a client pool size of 4, I noticed there are 4-5 peaks in the load distributions for both user services and video services. Most importantly, the qps to the two hosts are relatively balanced compared to a pool size of 1. THe two peaks are closer to each other, meaning that the connections are more evenly distributed over the two hosts. If we use a pool size of 8, I predict that the qps to the two hosts will be even closer to each other, i.e the connection loads will be more balanced. 